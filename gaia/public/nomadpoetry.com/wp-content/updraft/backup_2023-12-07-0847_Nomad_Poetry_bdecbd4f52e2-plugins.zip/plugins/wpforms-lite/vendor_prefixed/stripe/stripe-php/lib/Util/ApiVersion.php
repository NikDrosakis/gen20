<?php

// File generated from our OpenAPI spec
namespace WPForms\Vendor\Stripe\Util;

class ApiVersion
{
    const CURRENT = '2022-11-15';
}
