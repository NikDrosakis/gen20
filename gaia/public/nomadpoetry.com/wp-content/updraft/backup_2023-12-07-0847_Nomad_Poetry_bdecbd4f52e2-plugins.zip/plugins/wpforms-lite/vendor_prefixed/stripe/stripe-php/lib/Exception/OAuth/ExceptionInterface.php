<?php

namespace WPForms\Vendor\Stripe\Exception\OAuth;

/**
 * The base interface for all Stripe OAuth exceptions.
 */
interface ExceptionInterface extends \WPForms\Vendor\Stripe\Exception\ExceptionInterface
{
}
