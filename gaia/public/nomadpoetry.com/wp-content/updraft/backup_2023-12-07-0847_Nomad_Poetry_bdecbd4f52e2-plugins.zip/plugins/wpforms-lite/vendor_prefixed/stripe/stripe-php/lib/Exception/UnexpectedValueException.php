<?php

namespace WPForms\Vendor\Stripe\Exception;

class UnexpectedValueException extends \UnexpectedValueException implements ExceptionInterface
{
}
