<?php

namespace WPForms\Vendor\Stripe\Exception;

class BadMethodCallException extends \BadMethodCallException implements ExceptionInterface
{
}
