<?php
// newsmash_hdr_left_ttl
function newsmash_hdr_left_ttl_render_callback() {
	return get_theme_mod( 'newsmash_hdr_left_ttl' );
}

// newsmash_hdr_left_text
function newsmash_hdr_left_text_render_callback() {
	return get_theme_mod( 'newsmash_hdr_left_text' );
}

// newsmash_hdr_top_ads_title
function newsmash_hdr_top_ads_title_render_callback() {
	return get_theme_mod( 'newsmash_hdr_top_ads_title' );
}

// newsmash_hdr_btn_lbl
function newsmash_hdr_btn_lbl_render_callback() {
	return get_theme_mod( 'newsmash_hdr_btn_lbl' );
}

// newsmash_latest_post_ttl
function newsmash_latest_post_ttl_render_callback() {
	return get_theme_mod( 'newsmash_latest_post_ttl' );
}

// newsmash_footer_copyright_text
function newsmash_footer_copyright_text_render_callback() {
	return get_theme_mod( 'newsmash_footer_copyright_text' );
}

// newsmash_scroller_text
function newsmash_scroller_text_render_callback() {
	return get_theme_mod( 'newsmash_scroller_text' );
}

// newsmash_other_story_ttl
function newsmash_other_story_ttl_render_callback() {
	return get_theme_mod( 'newsmash_other_story_ttl' );
}

// newsmash_top_tags_ttl
function newsmash_top_tags_ttl_render_callback() {
	return get_theme_mod( 'newsmash_top_tags_ttl' );
}